#!/usr/bin/python
# -*- coding: utf-8 -*-

# importing the packages and modules for turtlesim simulation

import math as m
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

# initialization of global variables

TURTLE_X = 0.0
TURTLE_Y = 0.0
TURTLE_THETA = 0
PREVIOUS_ANGLE = 0
DISTANCE = 0


# defining subscriber callback function

def pose_callback(pose):
    global TURTLE_X, TURTLE_Y, TURTLE_THETA
    TURTLE_X = pose.x
    TURTLE_Y = pose.y
    TURTLE_THETA = pose.theta


# function for the turtle simulation

def move_turtle():
    global TURTLE_X, TURTLE_Y, DISTANCE, TURTLE_THETA, PREVIOUS_ANGLE

    # initializing node
    rospy.init_node('node_turtle_revolve', anonymous=True)

    # initailizing publisher....
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)

    # initializing subscriber....
    rospy.Subscriber('/turtle1/pose', Pose, pose_callback)

    rate = rospy.Rate(10)  # Rate = 10Hz
    vel = Twist()  # Assigning publisher
    while not rospy.is_shutdown():

        # linear velocities
        vel.linear.x = 0.5
        vel.linear.y = 0
        vel.linear.z = 0

        # angular velocities
        vel.angular.x = 0
        vel.angular.y = 0
        vel.angular.z = 0.25

        radius = vel.linear.x/vel.angular.z

        # condition for stopping of turtle
        # optional: if we are checking angle, (angle >= 2*m.pi) is the condition
        if DISTANCE >= 2 * m.pi * radius:
            rospy.loginfo('Turtle reached destination')
            rospy.logwarn('Stopping turtle')
            break

        # updating the DISTANCE
        # optional: updating angle = angle + abs(previous-theta)
        DISTANCE = DISTANCE + radius * abs(abs(TURTLE_THETA) - abs(PREVIOUS_ANGLE))

        # updating angle........
        PREVIOUS_ANGLE = TURTLE_THETA

        # calling publisher........
        pub.publish(vel)

        rate.sleep()
        rospy.loginfo('Moving in circle\nDISTANCE = %f', DISTANCE)

if __name__ == '__main__':
    try:
        move_turtle()
    except rospy.ROSInterruptException:
        pass